﻿namespace Pmetodos
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LblPalavra1 = new System.Windows.Forms.Label();
            this.LblPalavra2 = new System.Windows.Forms.Label();
            this.TxtPalavra1 = new System.Windows.Forms.TextBox();
            this.TxtPalavra2 = new System.Windows.Forms.TextBox();
            this.BtnVerificar = new System.Windows.Forms.Button();
            this.BtnInserir = new System.Windows.Forms.Button();
            this.BtnInserir2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LblPalavra1
            // 
            this.LblPalavra1.AutoSize = true;
            this.LblPalavra1.Location = new System.Drawing.Point(53, 27);
            this.LblPalavra1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblPalavra1.Name = "LblPalavra1";
            this.LblPalavra1.Size = new System.Drawing.Size(52, 13);
            this.LblPalavra1.TabIndex = 0;
            this.LblPalavra1.Text = "Palavra 1";
            // 
            // LblPalavra2
            // 
            this.LblPalavra2.AutoSize = true;
            this.LblPalavra2.Location = new System.Drawing.Point(53, 85);
            this.LblPalavra2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblPalavra2.Name = "LblPalavra2";
            this.LblPalavra2.Size = new System.Drawing.Size(52, 13);
            this.LblPalavra2.TabIndex = 1;
            this.LblPalavra2.Text = "Palavra 2";
            // 
            // TxtPalavra1
            // 
            this.TxtPalavra1.Location = new System.Drawing.Point(271, 23);
            this.TxtPalavra1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtPalavra1.Name = "TxtPalavra1";
            this.TxtPalavra1.Size = new System.Drawing.Size(68, 20);
            this.TxtPalavra1.TabIndex = 2;
            // 
            // TxtPalavra2
            // 
            this.TxtPalavra2.Location = new System.Drawing.Point(271, 81);
            this.TxtPalavra2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TxtPalavra2.Name = "TxtPalavra2";
            this.TxtPalavra2.Size = new System.Drawing.Size(68, 20);
            this.TxtPalavra2.TabIndex = 3;
            // 
            // BtnVerificar
            // 
            this.BtnVerificar.Location = new System.Drawing.Point(65, 157);
            this.BtnVerificar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnVerificar.Name = "BtnVerificar";
            this.BtnVerificar.Size = new System.Drawing.Size(67, 47);
            this.BtnVerificar.TabIndex = 4;
            this.BtnVerificar.Text = "Verifica a igualdade";
            this.BtnVerificar.UseVisualStyleBackColor = true;
            this.BtnVerificar.Click += new System.EventHandler(this.BtnVerificar_Click);
            // 
            // BtnInserir
            // 
            this.BtnInserir.Location = new System.Drawing.Point(179, 157);
            this.BtnInserir.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnInserir.Name = "BtnInserir";
            this.BtnInserir.Size = new System.Drawing.Size(67, 47);
            this.BtnInserir.TabIndex = 5;
            this.BtnInserir.Text = "Inseri o 1 no meio do 2";
            this.BtnInserir.UseVisualStyleBackColor = true;
            this.BtnInserir.Click += new System.EventHandler(this.BtnInserir_Click);
            // 
            // BtnInserir2
            // 
            this.BtnInserir2.Location = new System.Drawing.Point(287, 157);
            this.BtnInserir2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnInserir2.Name = "BtnInserir2";
            this.BtnInserir2.Size = new System.Drawing.Size(70, 47);
            this.BtnInserir2.TabIndex = 6;
            this.BtnInserir2.Text = "Inserir 2 * no meio do 1";
            this.BtnInserir2.UseVisualStyleBackColor = true;
            this.BtnInserir2.Click += new System.EventHandler(this.BtnInserir2_Click);
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.BtnInserir2);
            this.Controls.Add(this.BtnInserir);
            this.Controls.Add(this.BtnVerificar);
            this.Controls.Add(this.TxtPalavra2);
            this.Controls.Add(this.TxtPalavra1);
            this.Controls.Add(this.LblPalavra2);
            this.Controls.Add(this.LblPalavra1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LblPalavra1;
        private System.Windows.Forms.Label LblPalavra2;
        private System.Windows.Forms.TextBox TxtPalavra1;
        private System.Windows.Forms.TextBox TxtPalavra2;
        private System.Windows.Forms.Button BtnVerificar;
        private System.Windows.Forms.Button BtnInserir;
        private System.Windows.Forms.Button BtnInserir2;
    }
}