﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void BtnInserir2_Click(object sender, EventArgs e)
        {
            char[] vetor = TxtPalavra1.Text.ToCharArray();
            Array.Reverse(vetor);
            string auxiliar = new string(vetor);
            TxtPalavra2.Text = auxiliar;
        }

        private void BtnInserir_Click(object sender, EventArgs e)
        {
            TxtPalavra2.Text = TxtPalavra2.Text.Replace(TxtPalavra1.Text, "");
        }
    }
}
