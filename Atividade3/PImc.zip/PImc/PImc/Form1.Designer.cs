﻿namespace PImc
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Lbl1 = new System.Windows.Forms.Label();
            this.Lbl2 = new System.Windows.Forms.Label();
            this.Lbl3 = new System.Windows.Forms.Label();
            this.Txt1 = new System.Windows.Forms.TextBox();
            this.Txt2 = new System.Windows.Forms.TextBox();
            this.TxtIMC = new System.Windows.Forms.TextBox();
            this.BtnIMC = new System.Windows.Forms.Button();
            this.Btn2 = new System.Windows.Forms.Button();
            this.Btn3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Lbl1
            // 
            this.Lbl1.AutoSize = true;
            this.Lbl1.Location = new System.Drawing.Point(89, 88);
            this.Lbl1.Name = "Lbl1";
            this.Lbl1.Size = new System.Drawing.Size(45, 20);
            this.Lbl1.TabIndex = 0;
            this.Lbl1.Text = "Peso";
            // 
            // Lbl2
            // 
            this.Lbl2.AutoSize = true;
            this.Lbl2.Location = new System.Drawing.Point(89, 167);
            this.Lbl2.Name = "Lbl2";
            this.Lbl2.Size = new System.Drawing.Size(51, 20);
            this.Lbl2.TabIndex = 1;
            this.Lbl2.Text = "Altura";
            // 
            // Lbl3
            // 
            this.Lbl3.AutoSize = true;
            this.Lbl3.Location = new System.Drawing.Point(89, 244);
            this.Lbl3.Name = "Lbl3";
            this.Lbl3.Size = new System.Drawing.Size(38, 20);
            this.Lbl3.TabIndex = 2;
            this.Lbl3.Text = "IMC";
            // 
            // Txt1
            // 
            this.Txt1.Location = new System.Drawing.Point(380, 88);
            this.Txt1.Name = "Txt1";
            this.Txt1.Size = new System.Drawing.Size(100, 26);
            this.Txt1.TabIndex = 3;
            this.Txt1.Validating += new System.ComponentModel.CancelEventHandler(this.Txt1_Validating);
            // 
            // Txt2
            // 
            this.Txt2.Location = new System.Drawing.Point(380, 167);
            this.Txt2.Name = "Txt2";
            this.Txt2.Size = new System.Drawing.Size(100, 26);
            this.Txt2.TabIndex = 4;
            this.Txt2.TextChanged += new System.EventHandler(this.Txt2_TextChanged);
            this.Txt2.Validating += new System.ComponentModel.CancelEventHandler(this.Txt2_Validating);
            // 
            // TxtIMC
            // 
            this.TxtIMC.Location = new System.Drawing.Point(380, 244);
            this.TxtIMC.Name = "TxtIMC";
            this.TxtIMC.ReadOnly = true;
            this.TxtIMC.Size = new System.Drawing.Size(100, 26);
            this.TxtIMC.TabIndex = 5;
            // 
            // BtnIMC
            // 
            this.BtnIMC.Location = new System.Drawing.Point(93, 350);
            this.BtnIMC.Name = "BtnIMC";
            this.BtnIMC.Size = new System.Drawing.Size(75, 53);
            this.BtnIMC.TabIndex = 6;
            this.BtnIMC.Text = "Calcular IMC";
            this.BtnIMC.UseVisualStyleBackColor = true;
            this.BtnIMC.Click += new System.EventHandler(this.Btn1_Click);
            // 
            // Btn2
            // 
            this.Btn2.Location = new System.Drawing.Point(300, 350);
            this.Btn2.Name = "Btn2";
            this.Btn2.Size = new System.Drawing.Size(75, 53);
            this.Btn2.TabIndex = 7;
            this.Btn2.Text = "Apagar";
            this.Btn2.UseVisualStyleBackColor = true;
            this.Btn2.Click += new System.EventHandler(this.Btn2_Click);
            // 
            // Btn3
            // 
            this.Btn3.Location = new System.Drawing.Point(500, 350);
            this.Btn3.Name = "Btn3";
            this.Btn3.Size = new System.Drawing.Size(75, 53);
            this.Btn3.TabIndex = 8;
            this.Btn3.Text = "Sair";
            this.Btn3.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Btn3);
            this.Controls.Add(this.Btn2);
            this.Controls.Add(this.BtnIMC);
            this.Controls.Add(this.TxtIMC);
            this.Controls.Add(this.Txt2);
            this.Controls.Add(this.Txt1);
            this.Controls.Add(this.Lbl3);
            this.Controls.Add(this.Lbl2);
            this.Controls.Add(this.Lbl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl1;
        private System.Windows.Forms.Label Lbl2;
        private System.Windows.Forms.Label Lbl3;
        private System.Windows.Forms.TextBox Txt1;
        private System.Windows.Forms.TextBox Txt2;
        private System.Windows.Forms.TextBox TxtIMC;
        private System.Windows.Forms.Button BtnIMC;
        private System.Windows.Forms.Button Btn2;
        private System.Windows.Forms.Button Btn3;
    }
}

