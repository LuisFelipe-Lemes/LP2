﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pestoque02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            int[,] produto = new int[4, 4];
            int Total = 0;
            int TotalSemanas = 0;
            string auxiliar = "";

            for (int i = 0; i < 4; i++)
            {



                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a entrada do Produto {j + 1} Semana {i + 1}", "Entrada de dados");

                    if (!int.TryParse(auxiliar, out produto[i, j]) || produto[i, j] <= 0)
                    {
                        MessageBox.Show("Dados inválidos");
                        j--;
                    }

                    else
                    {
                        LstdbMateriais.Items.Add($"TotalEntradas do Produto {i + 1} Semana {j + 1} - {auxiliar} \n\n");

                        Total =+ produto[i, j];
                        TotalSemanas =+ produto[i, j];
                    }

                }
                LstdbMateriais.Items.Add($"TotalEntradas do Produto {i + 1}     {Total}");
            }
            LstdbMateriais.Items.Add($"Total Geral Entradas:         {TotalSemanas}");
        




        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            LstdbMateriais.Items.Clear();
        }
    }
}
