﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmetodos
{
    public partial class FrmExercicio4 : Form
    {
        public FrmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Contanumero = 0;
            int posicao = 0;

            while (posicao < richTextBox1.Text.Length)
            {
                if (Char.IsNumber(richTextBox1.Text[posicao]))
                {
                    Contanumero++;
                }

                posicao++;

            }

            MessageBox.Show($"o texto tem{Contanumero} números");

        }

        private void EspacoBranco_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < richTextBox1.Text.Length; i++)
            {
                if (Char.IsWhiteSpace(richTextBox1.Text[i]))
                {
                    MessageBox.Show($"O primeiro caracter branco está na posição {i + 1} ");
                    break;
                }
            }
        }

        private void ContaLetra_Click(object sender, EventArgs e)
        {
            int contaletra = 0;
            foreach (char c in richTextBox1.Text)
            {
                if (char.IsLetter(c))
                {
                    contaletra++;
                }
            }

            MessageBox.Show($"O texto contem {contaletra} letras");

        }
    }
}
