﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
        double Imc;
        double Altura;
        double Peso;
        public Form1()
        {
            InitializeComponent();
        }

        private void Txt1_Validating(object sender, CancelEventArgs e)
        {
            if (!Double.TryParse(Txt1.Text, out Peso))
            {
                MessageBox.Show("Número inválido!");
                Focus();
            }
            else if (Peso <= 0)
            {
                MessageBox.Show("Número menor que zero!");
                Focus();
            }
            
               
         }

        private void Txt2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Txt2_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(Txt2.Text, out Altura))
            {
                MessageBox.Show("Não é um número!");
                Focus();
            }
            else if (Altura <= 0)
            {
                MessageBox.Show("Número menor que zero!");
                Focus();
            }
            
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            
            Imc = Peso/( Altura * Altura);
            Imc = Math.Round(Imc, 1);
            TxtIMC.Text = Imc.ToString();
            if (Imc < 18.5)
            {
                MessageBox.Show("MAGREZA");
            }
            else if (Imc <= 24.9)
            {
                MessageBox.Show("NORMAL");
            }
            else if (Imc <= 29.9)
            {
                MessageBox.Show("SOBREPESO");
            }
            else if (Imc <= 39.9)
            {
                MessageBox.Show("OBESIDADE");
            }
            else
            {
                MessageBox.Show("OBESIDADE EXTREMA");
            }
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            Txt1.Text = "";
            Txt2.Text = "";
            TxtIMC.Text = "";
        }
    }
}
