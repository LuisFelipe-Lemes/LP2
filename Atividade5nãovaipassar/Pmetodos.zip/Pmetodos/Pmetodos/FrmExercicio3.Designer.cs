﻿namespace Pmetodos
{
    partial class FrmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnInserir2 = new System.Windows.Forms.Button();
            this.BtnInserir = new System.Windows.Forms.Button();
            this.TxtPalavra2 = new System.Windows.Forms.TextBox();
            this.TxtPalavra1 = new System.Windows.Forms.TextBox();
            this.LblPalavra2 = new System.Windows.Forms.Label();
            this.LblPalavra1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // BtnInserir2
            // 
            this.BtnInserir2.Location = new System.Drawing.Point(498, 292);
            this.BtnInserir2.Name = "BtnInserir2";
            this.BtnInserir2.Size = new System.Drawing.Size(105, 73);
            this.BtnInserir2.TabIndex = 13;
            this.BtnInserir2.Text = "Inverter";
            this.BtnInserir2.UseVisualStyleBackColor = true;
            this.BtnInserir2.Click += new System.EventHandler(this.BtnInserir2_Click);
            // 
            // BtnInserir
            // 
            this.BtnInserir.Location = new System.Drawing.Point(176, 292);
            this.BtnInserir.Name = "BtnInserir";
            this.BtnInserir.Size = new System.Drawing.Size(101, 73);
            this.BtnInserir.TabIndex = 12;
            this.BtnInserir.Text = "Remove a palavra 1 da palavra 2";
            this.BtnInserir.UseVisualStyleBackColor = true;
            this.BtnInserir.Click += new System.EventHandler(this.BtnInserir_Click);
            // 
            // TxtPalavra2
            // 
            this.TxtPalavra2.Location = new System.Drawing.Point(498, 175);
            this.TxtPalavra2.Name = "TxtPalavra2";
            this.TxtPalavra2.Size = new System.Drawing.Size(100, 26);
            this.TxtPalavra2.TabIndex = 10;
            // 
            // TxtPalavra1
            // 
            this.TxtPalavra1.Location = new System.Drawing.Point(498, 86);
            this.TxtPalavra1.Name = "TxtPalavra1";
            this.TxtPalavra1.Size = new System.Drawing.Size(100, 26);
            this.TxtPalavra1.TabIndex = 9;
            // 
            // LblPalavra2
            // 
            this.LblPalavra2.AutoSize = true;
            this.LblPalavra2.Location = new System.Drawing.Point(172, 181);
            this.LblPalavra2.Name = "LblPalavra2";
            this.LblPalavra2.Size = new System.Drawing.Size(74, 20);
            this.LblPalavra2.TabIndex = 8;
            this.LblPalavra2.Text = "Palavra 2";
            // 
            // LblPalavra1
            // 
            this.LblPalavra1.AutoSize = true;
            this.LblPalavra1.Location = new System.Drawing.Point(172, 92);
            this.LblPalavra1.Name = "LblPalavra1";
            this.LblPalavra1.Size = new System.Drawing.Size(74, 20);
            this.LblPalavra1.TabIndex = 7;
            this.LblPalavra1.Text = "Palavra 1";
            // 
            // FrmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnInserir2);
            this.Controls.Add(this.BtnInserir);
            this.Controls.Add(this.TxtPalavra2);
            this.Controls.Add(this.TxtPalavra1);
            this.Controls.Add(this.LblPalavra2);
            this.Controls.Add(this.LblPalavra1);
            this.Name = "FrmExercicio3";
            this.Text = "FrmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnInserir2;
        private System.Windows.Forms.Button BtnInserir;
        private System.Windows.Forms.TextBox TxtPalavra2;
        private System.Windows.Forms.TextBox TxtPalavra1;
        private System.Windows.Forms.Label LblPalavra2;
        private System.Windows.Forms.Label LblPalavra1;
    }
}