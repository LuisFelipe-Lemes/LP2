﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    { double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void TxtNumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(TxtNumero2, "");
                numero2 = Convert.ToDouble(TxtNumero2.Text);
            }
            catch
            {
                errorProvider2.SetError(TxtNumero2, "Numero 2 INválido1");
                TxtNumero2.Focus();
            }
         
        }

        private void BtnMenos_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            TxtResultado.Text = resultado.ToString();
        }

        private void BtnVezes_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            TxtResultado.Text = resultado.ToString(); 
        }

        private void BtnDividir_Click(object sender, EventArgs e)
        {
            if (numero1 == 0)
            {
                MessageBox.Show("Numero inválido");
                TxtNumero1.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                TxtResultado.Text = resultado.ToString();
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtNumero1.Text = "";
            TxtNumero2.Text = "";
            TxtResultado.Text = "";
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair?","Saida", MessageBoxButtons.YesNo,MessageBoxIcon.Question) ==
                DialogResult.Yes) { Close(); }
        }

        private void BtnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            TxtResultado.Text = resultado.ToString();
        }

        private void TxtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(TxtNumero1.Text, out numero1))
            {
                errorProvider1.SetError(TxtNumero1, " Numero 1 inválido!");
                TxtNumero1.Focus();
            }
            else
                errorProvider1.SetError(TxtNumero1, "");
        }
    }
}
